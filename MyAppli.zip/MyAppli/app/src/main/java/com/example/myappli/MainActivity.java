package com.example.myappli;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    AlarmManager alarmManager;
    Button btn_start, btn_stop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_start=findViewById(R.id.btn_start);
        btn_stop=findViewById(R.id.btn_stop);

        btn_start.setOnClickListener(click);
        btn_stop.setOnClickListener(click);

    }//onCreate

    View.OnClickListener click = new View.OnClickListener() {
        @Override
        public void  onClick(View view) {

            Intent receiverIntent = null;
            PendingIntent pendingIntent = null;

            switch ( view.getId()) {

                case  R.id.btn_start:
                    alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
                    receiverIntent = new Intent(MainActivity.this,MyReceiver.class);



                    pendingIntent = PendingIntent.getBroadcast(
                            MainActivity.this, 0,
                            receiverIntent,PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.setRepeating( AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime(),1000*60,pendingIntent);
                    break;

                case  R.id.btn_stop:
                    alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
                    receiverIntent = new Intent(MainActivity.this,MyReceiver.class);


                    pendingIntent = PendingIntent.getBroadcast(
                            MainActivity.this, 0,
                            receiverIntent,PendingIntent.FLAG_UPDATE_CURRENT);



                    alarmManager.cancel(pendingIntent);
                    break;
            }


        }
    };

}